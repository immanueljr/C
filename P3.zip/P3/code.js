var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["c1090950-0f8d-4d62-93eb-18d7ae1fd681"],"propsByKey":{"c1090950-0f8d-4d62-93eb-18d7ae1fd681":{"name":"animalhead_lion_1","sourceUrl":null,"frameSize":{"x":400,"y":380},"frameCount":1,"looping":true,"frameDelay":12,"version":"yJXeK2kbcW6.JUIarnOjPC9G2DMR9kGn","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":380},"rootRelativePath":"assets/c1090950-0f8d-4d62-93eb-18d7ae1fd681.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----







var Sofia,wall1,wall2,wall3,wall4,wall5,wall6,wall7,wall8,wall9,wall10,
wall11,wall12,wall13,wall14,wall15,wall16,wall17,wall18,wall19,wall20,
wall21,wall22,target;



Sofia = createSprite(20,20,18,18);
Sofia.shapeColor = "yellow"; 

wall1 = createSprite(10,70,100,20);
wall2 = createSprite(30,70,100,20);
wall3 = createSprite(80,130,100,20);
wall4 = createSprite(70,240,20,100);
wall5 = createSprite(100,300,20,100);
wall6 = createSprite(180,310,100,20);
wall7 = createSprite(30,352,20,100);
wall8 = createSprite(175,352,20,100);
wall9 = createSprite(280,290,20,100);
wall10 = createSprite(270,150100,20);
wall11 = createSprite(330,50,100,20);
wall12 = createSprite(340,125,20,100);
wall13 = createSprite(220,250,20,100);
wall14 = createSprite(330,210,150,20);
wall15 = createSprite(100,300,20,100);
wall16 = createSprite(180,310,100,20);
wall17 = createSprite(30,352,20,100);
wall18 = createSprite(175,352,20,100);
wall19 = createSprite(280,290,20,100);
wall20 = createSprite(350,270,120,20);
wall21 = createSprite(250,390,100,20);
wall22 = createSprite(330,370,20,100);


target = createSprite(395,375,10,50);
target.shapeColor = "black";

function draw() {
  background("pink");
  
  Sofia.velocityX=0
  Sofia.velocityY=0
  
 if (Sofia.bounce(target)) {
    textSize(38);
    textFont("Algerian");
    fill ("black");
    text("you won",130,100);
 }
 
  if (keyDown("DOWN_ARROW"))
  {
    
    Sofia.velocityX=0
    Sofia.velocityY=5
  }
    
  if (keyDown("UP_ARROW"))
  {
    Sofia.velocityX=0;
    Sofia.velocityY=-5;
   }   
   
   
  if (keyDown("LEFT_ARROW")) {
    Sofia.velocityX=-5;
    Sofia.velocityY=0;
  }
    
  if (keyDown("RIGHT_ARROW")) {
    Sofia.velocityX=5;
    Sofia.velocityY=0;
  }
  

if (Sofia.isTouching(wall1)||Sofia.isTouching(wall2)||Sofia.isTouching(wall3)||Sofia.isTouching(wall4)||Sofia.isTouching(wall5)||Sofia.isTouching(wall6)||Sofia.isTouching(wall7)||Sofia.isTouching(wall8)||Sofia.isTouching(wall9)||Sofia.isTouching(wall10)||Sofia.isTouching(wall11)||Sofia.isTouching(wall12)||Sofia.isTouching(wall13)||Sofia.isTouching(wall14)||Sofia.isTouching(wall15)||Sofia.isTouching(wall16)||Sofia.isTouching(wall17)||Sofia.isTouching(wall18)||Sofia.isTouching(wall19)||Sofia.isTouching(wall20)||Sofia.isTouching(wall21)||Sofia.isTouching(wall22)||Sofia.isTouching(target)){
  Sofia.x=20;
  Sofia.y=20;
}


   Sofia.collide(target);
 createEdgeSprites();
Sofia.bounceOff(edges);
 
drawSprites();




}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
